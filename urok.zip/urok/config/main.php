<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
define("ROOT_DIR", $_SERVER['DOCUMENT_ROOT'] . "/../");
define("CONTROLLERS_NAMESPACE", '\app\controllers\\');