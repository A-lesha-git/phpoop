<?php


namespace app\models;


abstract class Model
{

}