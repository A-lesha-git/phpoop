<?php
namespace app\interfaces;

interface IDataModel
{}