<h1><?=$product->title?></h1>
<p>
    <?=$product->description?>
</p>