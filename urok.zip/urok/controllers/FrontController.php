<?php


namespace app\controllers;


use app\services\Request;
use app\services\RequestNotMatchException;

class FrontController extends Controller
{
    private $controller;
    private $action;

    private $defaultController = "Product";

    public function actionIndex()
    {
        try{
            $rm = new Request();
        }catch (RequestNotMatchException $e){
            echo "2";
        }

        
        $controllerName = $rm->getControllerName() ?: $this->defaultController;
        $this->action = $rm->getActionName();

        $this->controller = CONTROLLERS_NAMESPACE . ucfirst($controllerName) . "Controller";
        $controller = new $this->controller(
            new \app\services\renderers\TemplateRenderer()
        );
        $controller->runAction($this->action);
    }
}